import { useState, useEffect, useRef } from "react";
import {
  TrendingUp, Bell, Bot, Calculator, FlaskConical, Users, Shield, Zap, Target,
  ChevronDown, ArrowLeft, CheckCircle, AlertTriangle, Wallet, BarChart3,
  BrainCircuit, Sparkles, Menu, X, Star, Clock, PiggyBank, ShoppingCart,
  CreditCard, Activity, Send, Home, Settings, ArrowRight, Eye, EyeOff,
  ChevronRight, Building2, Lock, Phone, Mail, User, MapPin, Heart,
  TrendingDown, Check, Loader2, LayoutDashboard,
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine,
} from "recharts";

// ─────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────
type Page =
  | "landing" | "auth" | "login" | "signup"
  | "setup-intro" | "setup-basic" | "setup-income"
  | "setup-commitments" | "setup-budget" | "setup-goals"
  | "setup-bank" | "analyzing" | "first-result" | "dashboard";

// ─────────────────────────────────────────────────────────────────
// Circular Pulse Gauge (unchanged)
// ─────────────────────────────────────────────────────────────────
function PulseGauge({ value = 78, size = 180 }: { value?: number; size?: number }) {
  const radius = size / 2 - 18;
  const circumference = 2 * Math.PI * radius;
  const progress = (value / 100) * circumference;
  const color = value >= 70 ? "#16A34A" : value >= 45 ? "#F59E0B" : "#DC2626";
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="rotate-[-90deg]">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E0EFFE" strokeWidth="12" />
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth="12"
          strokeLinecap="round" strokeDasharray={`${progress} ${circumference}`}
          style={{ transition: "stroke-dasharray 1s ease" }} />
      </svg>
      <div className="absolute flex flex-col items-center justify-center">
        <span className="text-4xl font-black" style={{ color, fontFamily: "Cairo, sans-serif" }}>{value}</span>
        <span className="text-xs text-slate-500 font-semibold mt-0.5" style={{ fontFamily: "Tajawal, sans-serif" }}>/ 100</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Heartbeat Line (unchanged)
// ─────────────────────────────────────────────────────────────────
function HeartbeatLine({ color = "#1D4ED8" }: { color?: string }) {
  return (
    <svg viewBox="0 0 200 50" className="w-full h-8" preserveAspectRatio="none">
      <polyline points="0,25 30,25 40,10 50,40 60,15 70,30 80,25 110,25 120,5 130,45 140,20 150,28 200,25"
        fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
        style={{ opacity: 0.7 }} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────
// Gradient Badge (unchanged)
// ─────────────────────────────────────────────────────────────────
function GradientBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-white text-sm font-semibold"
      style={{ background: "linear-gradient(135deg, #1D4ED8 0%, #16A34A 100%)", fontFamily: "Tajawal, sans-serif" }}>
      {children}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────
// Section Title (unchanged)
// ─────────────────────────────────────────────────────────────────
function SectionTitle({ badge, title, subtitle }: { badge?: string; title: string; subtitle?: string }) {
  return (
    <div className="text-center mb-14">
      {badge && <div className="flex justify-center mb-4"><GradientBadge>{badge}</GradientBadge></div>}
      <h2 className="text-4xl font-black text-slate-900 mb-4 leading-tight" style={{ fontFamily: "Cairo, sans-serif" }}>{title}</h2>
      {subtitle && <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{subtitle}</p>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Alert Card (unchanged)
// ─────────────────────────────────────────────────────────────────
function AlertCard({ icon: Icon, color, text, time }: { icon: any; color: string; text: string; time: string }) {
  return (
    <div className="flex items-start gap-3 bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + "18" }}>
        <Icon size={18} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-slate-700 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{text}</p>
        <span className="text-xs text-slate-400 mt-1 inline-block">{time}</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Feature Card (unchanged)
// ─────────────────────────────────────────────────────────────────
function FeatureCard({ icon: Icon, title, desc, gradient }: { icon: any; title: string; desc: string; gradient: string }) {
  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col gap-4">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: gradient }}>
        <Icon size={26} className="text-white" />
      </div>
      <div>
        <h3 className="text-lg font-bold text-slate-900 mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>{title}</h3>
        <p className="text-sm text-slate-500 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{desc}</p>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Onboarding Progress Bar
// ─────────────────────────────────────────────────────────────────
const ONBOARDING_STEPS = [
  "إنشاء الحساب",
  "البيانات الأساسية",
  "الدخل والالتزامات",
  "الميزانية والأهداف",
  "ربط الحساب البنكي",
  "تحليل البيانات",
  "مؤشر نبض جاهز",
];

function OnboardingProgress({ current }: { current: number }) {
  return (
    <div className="w-full max-w-2xl mx-auto mb-8">
      <div className="flex items-center justify-between gap-1">
        {ONBOARDING_STEPS.map((step, idx) => (
          <div key={step} className="flex flex-col items-center flex-1">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1 transition-all
              ${idx < current ? "bg-green-500 text-white" : idx === current ? "text-white" : "bg-slate-200 text-slate-400"}`}
              style={idx === current ? { background: "linear-gradient(135deg,#1D4ED8,#16A34A)" } : undefined}>
              {idx < current ? <Check size={13} /> : idx + 1}
            </div>
            <span className={`text-[9px] text-center leading-tight hidden sm:block ${idx <= current ? "text-blue-700 font-semibold" : "text-slate-400"}`}
              style={{ fontFamily: "Tajawal, sans-serif" }}>{step}</span>
          </div>
        ))}
      </div>
      <div className="relative mt-2 h-1.5 bg-slate-200 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${(current / (ONBOARDING_STEPS.length - 1)) * 100}%`, background: "linear-gradient(90deg,#1D4ED8,#16A34A)" }} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Shared page wrapper for auth/onboarding pages
// ─────────────────────────────────────────────────────────────────
function PageWrapper({ children, showBack, onBack }: { children: React.ReactNode; showBack?: boolean; onBack?: () => void }) {
  return (
    <div dir="rtl" className="min-h-screen flex flex-col" style={{ background: "linear-gradient(160deg,#EFF6FF 0%,#F0FDF4 100%)", fontFamily: "Tajawal, sans-serif" }}>
      {/* Mini Navbar */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">💓</span>
            <span className="font-black text-base" style={{ fontFamily: "Cairo, sans-serif", background: "linear-gradient(135deg,#1D4ED8,#16A34A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              نبض | Pulse
            </span>
          </div>
          {showBack && onBack && (
            <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-blue-700 transition-colors font-semibold">
              <ArrowRight size={16} />
              رجوع
            </button>
          )}
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-4">
        {children}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Input Field
// ─────────────────────────────────────────────────────────────────
function FormField({ label, type = "text", placeholder, icon: Icon, value, onChange, hint }: {
  label: string; type?: string; placeholder?: string; icon?: any; value: string; onChange: (v: string) => void; hint?: string;
}) {
  const [show, setShow] = useState(false);
  const isPassword = type === "password";
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-sm font-semibold text-slate-700" style={{ fontFamily: "Tajawal, sans-serif" }}>{label}</label>
      <div className="relative">
        {Icon && <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400"><Icon size={16} /></div>}
        <input
          type={isPassword ? (show ? "text" : "password") : type}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange(e.target.value)}
          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 text-sm text-slate-800 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
          style={{ paddingRight: Icon ? "2.5rem" : "1rem", paddingLeft: isPassword ? "2.5rem" : "1rem", fontFamily: "Tajawal, sans-serif" }}
        />
        {isPassword && (
          <button type="button" onClick={() => setShow(!show)} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
            {show ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        )}
      </div>
      {hint && <p className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>{hint}</p>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Auth Selection Page
// ─────────────────────────────────────────────────────────────────
function AuthPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <PageWrapper>
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-md"
              style={{ background: "linear-gradient(135deg,#EFF6FF,#F0FDF4)" }}>💓</div>
          </div>
          <h1 className="text-3xl font-black text-slate-900 mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>مرحبًا بك في نبض</h1>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
            سجّل دخولك أو أنشئ حسابًا جديدًا لبدء تحليل صحتك المالية.
          </p>
          <div className="flex flex-col gap-3">
            <button onClick={() => navigate("login")}
              className="w-full py-3.5 rounded-2xl font-bold text-white transition-all hover:shadow-lg hover:scale-[1.02] text-base"
              style={{ background: "linear-gradient(135deg,#1D4ED8,#2563EB)", fontFamily: "Cairo, sans-serif" }}>
              تسجيل الدخول
            </button>
            <button onClick={() => navigate("signup")}
              className="w-full py-3.5 rounded-2xl font-bold text-blue-700 bg-blue-50 border border-blue-200 hover:bg-blue-100 transition-all text-base"
              style={{ fontFamily: "Cairo, sans-serif" }}>
              إنشاء حساب جديد
            </button>
            <button onClick={() => navigate("setup-bank")}
              className="w-full py-3.5 rounded-2xl font-bold text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-all text-base flex items-center justify-center gap-2"
              style={{ fontFamily: "Cairo, sans-serif" }}>
              <Building2 size={18} className="text-blue-600" />
              الدخول عبر بنك الإنماء
            </button>
          </div>
          <button onClick={() => navigate("analyzing")}
            className="mt-4 text-sm text-slate-400 hover:text-blue-600 underline underline-offset-2 transition-colors"
            style={{ fontFamily: "Tajawal, sans-serif" }}>
            تجربة ببيانات تجريبية
          </button>
          <div className="mt-6 flex items-center gap-3 justify-center">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Shield size={12} className="text-green-500" /> اتصال آمن
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Lock size={12} className="text-blue-500" /> مشفر بالكامل
            </div>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Login Page
// ─────────────────────────────────────────────────────────────────
function LoginPage({ navigate }: { navigate: (p: Page) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  return (
    <PageWrapper showBack onBack={() => navigate("auth")}>
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="text-center mb-8">
            <div className="w-12 h-12 rounded-2xl mx-auto mb-4 flex items-center justify-center"
              style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
              <Lock size={22} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-slate-900" style={{ fontFamily: "Cairo, sans-serif" }}>تسجيل الدخول</h1>
            <p className="text-sm text-slate-400 mt-1" style={{ fontFamily: "Tajawal, sans-serif" }}>مرحبًا بعودتك إلى نبض</p>
          </div>
          <div className="flex flex-col gap-4 mb-6">
            <FormField label="البريد الإلكتروني أو رقم الجوال" placeholder="example@email.com" icon={Mail} value={email} onChange={setEmail} />
            <FormField label="كلمة المرور" type="password" placeholder="••••••••" icon={Lock} value={password} onChange={setPassword} />
          </div>
          <div className="flex justify-end mb-6">
            <button className="text-sm text-blue-600 hover:text-blue-800 font-semibold" style={{ fontFamily: "Tajawal, sans-serif" }}>
              نسيت كلمة المرور؟
            </button>
          </div>
          <button onClick={() => navigate("dashboard")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg hover:scale-[1.02]"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            دخول
          </button>
          <p className="text-center text-sm text-slate-400 mt-4" style={{ fontFamily: "Tajawal, sans-serif" }}>
            ليس لديك حساب؟{" "}
            <button onClick={() => navigate("signup")} className="text-blue-600 font-bold hover:underline">أنشئ حسابًا</button>
          </p>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Signup Page
// ─────────────────────────────────────────────────────────────────
function SignupPage({ navigate }: { navigate: (p: Page) => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  return (
    <PageWrapper showBack onBack={() => navigate("auth")}>
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="text-center mb-7">
            <div className="w-12 h-12 rounded-2xl mx-auto mb-4 flex items-center justify-center"
              style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
              <User size={22} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-slate-900" style={{ fontFamily: "Cairo, sans-serif" }}>إنشاء حساب جديد</h1>
            <p className="text-sm text-slate-400 mt-1" style={{ fontFamily: "Tajawal, sans-serif" }}>أنشئ حسابك لتبدأ رحلة فهم نبضك المالي</p>
          </div>
          <div className="flex flex-col gap-4 mb-6">
            <FormField label="الاسم الكامل" placeholder="أحمد عبدالله" icon={User} value={name} onChange={setName} />
            <FormField label="رقم الجوال" placeholder="05XXXXXXXX" icon={Phone} value={phone} onChange={setPhone} />
            <FormField label="البريد الإلكتروني" placeholder="example@email.com" icon={Mail} value={email} onChange={setEmail} />
            <FormField label="كلمة المرور" type="password" placeholder="8 أحرف على الأقل" icon={Lock} value={password} onChange={setPassword} />
            <FormField label="تأكيد كلمة المرور" type="password" placeholder="أعد إدخال كلمة المرور" icon={Lock} value={confirmPassword} onChange={setConfirmPassword} />
          </div>
          <button onClick={() => navigate("setup-intro")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg hover:scale-[1.02]"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            متابعة
          </button>
          <p className="text-center text-sm text-slate-400 mt-4" style={{ fontFamily: "Tajawal, sans-serif" }}>
            لديك حساب؟{" "}
            <button onClick={() => navigate("login")} className="text-blue-600 font-bold hover:underline">سجّل الدخول</button>
          </p>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Intro Page
// ─────────────────────────────────────────────────────────────────
function SetupIntroPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <PageWrapper showBack onBack={() => navigate("signup")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={0} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 text-center">
          <div className="text-5xl mb-6">💓</div>
          <h1 className="text-2xl font-black text-slate-900 mb-3" style={{ fontFamily: "Cairo, sans-serif" }}>
            لنبدأ ببناء نبضك المالي
          </h1>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
            سنطرح عليك عدة أسئلة بسيطة حتى نتمكن من حساب مؤشر النبض المالي الخاص بك بدقة.
          </p>
          <div className="flex flex-col gap-3 mb-8">
            {["إدخال بياناتك الأساسية", "تحديد مصادر دخلك والتزاماتك", "ضبط ميزانيتك وأهدافك المالية", "ربط حسابك البنكي بأمان تام"].map((step, i) => (
              <div key={step} className="flex items-center gap-3 bg-slate-50 rounded-2xl p-3 text-right">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                  style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>{i + 1}</div>
                <span className="text-sm text-slate-700 font-medium" style={{ fontFamily: "Tajawal, sans-serif" }}>{step}</span>
              </div>
            ))}
          </div>
          <button onClick={() => navigate("setup-basic")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            ابدأ الإعداد
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Basic Info
// ─────────────────────────────────────────────────────────────────
function SetupBasicPage({ navigate }: { navigate: (p: Page) => void }) {
  const [age, setAge] = useState("");
  const [city, setCity] = useState("");
  const [status, setStatus] = useState("");
  const [dependents, setDependents] = useState("");
  const [housing, setHousing] = useState("");
  const cities = ["الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة", "أبها", "تبوك", "القصيم"];
  const statuses = ["أعزب / عزباء", "متزوج / متزوجة", "مطلق / مطلقة", "أرمل / أرملة"];
  return (
    <PageWrapper showBack onBack={() => navigate("setup-intro")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={1} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>البيانات الأساسية</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>معلومات تساعدنا على تخصيص التحليل لك</p>
          </div>
          <div className="flex flex-col gap-4 mb-4">
            <FormField label="العمر" type="number" placeholder="25" icon={User} value={age} onChange={setAge} />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-slate-700">المدينة</label>
              <select value={city} onChange={e => setCity(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:border-blue-400 transition-all"
                style={{ fontFamily: "Tajawal, sans-serif" }}>
                <option value="">اختر مدينتك</option>
                {cities.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-slate-700">الحالة الاجتماعية</label>
              <div className="grid grid-cols-2 gap-2">
                {statuses.map(s => (
                  <button key={s} onClick={() => setStatus(s)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all text-right ${status === s ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
                    style={{ fontFamily: "Tajawal, sans-serif" }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <FormField label="عدد المعالين" type="number" placeholder="0" icon={Users} value={dependents} onChange={setDependents} hint="الأشخاص الذين تعولهم ماليًا" />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-slate-700">نوع السكن</label>
              <div className="grid grid-cols-3 gap-2">
                {["ملك", "إيجار", "مع الأهل"].map(h => (
                  <button key={h} onClick={() => setHousing(h)}
                    className={`py-2.5 rounded-xl text-sm font-semibold border transition-all ${housing === h ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
                    style={{ fontFamily: "Tajawal, sans-serif" }}>
                    {h}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-blue-50 rounded-2xl p-3 mb-5 flex items-start gap-2">
            <Shield size={15} className="text-blue-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-blue-700 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
              تساعدنا هذه البيانات على تقديم تحليل أدق ومقارنة أدائك المالي بشكل مجهول وآمن مع أشخاص مشابهين لك.
            </p>
          </div>
          <button onClick={() => navigate("setup-income")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            التالي
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Income Page
// ─────────────────────────────────────────────────────────────────
function SetupIncomePage({ navigate }: { navigate: (p: Page) => void }) {
  const [salary, setSalary] = useState("");
  const [salaryDay, setSalaryDay] = useState("");
  const [hasExtra, setHasExtra] = useState<boolean | null>(null);
  const [extraAmount, setExtraAmount] = useState("");
  return (
    <PageWrapper showBack onBack={() => navigate("setup-basic")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={2} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>مصادر الدخل</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>يساعدنا الدخل على حساب مؤشر نبضك بدقة</p>
          </div>
          <div className="flex flex-col gap-4 mb-4">
            <FormField label="الراتب الشهري (ريال سعودي)" type="number" placeholder="7,500" icon={Wallet} value={salary} onChange={setSalary} />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-slate-700">يوم نزول الراتب</label>
              <div className="grid grid-cols-5 gap-2">
                {[1, 5, 10, 15, 20, 25, 27, 28, 29, 30].map(d => (
                  <button key={d} onClick={() => setSalaryDay(String(d))}
                    className={`py-2 rounded-xl text-sm font-bold border transition-all ${salaryDay === String(d) ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
                    style={{ fontFamily: "Cairo, sans-serif" }}>
                    {d}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-slate-700">هل لديك دخل إضافي؟</label>
              <div className="grid grid-cols-2 gap-2">
                {[{ label: "نعم", val: true }, { label: "لا", val: false }].map(o => (
                  <button key={String(o.val)} onClick={() => setHasExtra(o.val)}
                    className={`py-3 rounded-xl text-sm font-bold border transition-all ${hasExtra === o.val ? "border-green-500 bg-green-50 text-green-700" : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
                    style={{ fontFamily: "Cairo, sans-serif" }}>
                    {o.label}
                  </button>
                ))}
              </div>
            </div>
            {hasExtra && (
              <FormField label="متوسط الدخل الإضافي الشهري (ريال)" type="number" placeholder="1,000" icon={TrendingUp} value={extraAmount} onChange={setExtraAmount} />
            )}
          </div>
          <div className="bg-green-50 rounded-2xl p-3 mb-5 flex items-start gap-2">
            <Sparkles size={15} className="text-green-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-green-700 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
              يستخدم نبض بيانات الدخل لحساب المبلغ الآمن للإنفاق اليومي وتوقع وضعك المالي القادم.
            </p>
          </div>
          <button onClick={() => navigate("setup-commitments")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            التالي
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Commitments Page
// ─────────────────────────────────────────────────────────────────
function SetupCommitmentsPage({ navigate }: { navigate: (p: Page) => void }) {
  const items = [
    { key: "rent", label: "إيجار", icon: Home, color: "#1D4ED8" },
    { key: "installments", label: "أقساط", icon: CreditCard, color: "#7C3AED" },
    { key: "loans", label: "قروض", icon: Wallet, color: "#DC2626" },
    { key: "cards", label: "بطاقات ائتمانية", icon: CreditCard, color: "#F59E0B" },
    { key: "bills", label: "فواتير", icon: Zap, color: "#0EA5E9" },
    { key: "subs", label: "اشتراكات شهرية", icon: Star, color: "#EC4899" },
    { key: "family", label: "مصاريف عائلية", icon: Heart, color: "#16A34A" },
    { key: "other", label: "أخرى", icon: Settings, color: "#64748B" },
  ];
  const [values, setValues] = useState<Record<string, string>>({});
  return (
    <PageWrapper showBack onBack={() => navigate("setup-income")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={2} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>الالتزامات الشهرية</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>أدخل مبالغ التزاماتك الثابتة كل شهر</p>
          </div>
          <div className="flex flex-col gap-3 mb-4">
            {items.map(item => (
              <div key={item.key} className="flex items-center gap-3 bg-slate-50 rounded-2xl px-4 py-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: item.color + "18" }}>
                  <item.icon size={16} style={{ color: item.color }} />
                </div>
                <span className="text-sm font-semibold text-slate-700 flex-1" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.label}</span>
                <input type="number" placeholder="0"
                  value={values[item.key] || ""}
                  onChange={e => setValues(v => ({ ...v, [item.key]: e.target.value }))}
                  className="w-24 bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-sm text-slate-800 text-center focus:outline-none focus:border-blue-400 transition-all"
                  style={{ fontFamily: "Cairo, sans-serif" }} />
              </div>
            ))}
          </div>
          <div className="bg-amber-50 rounded-2xl p-3 mb-5 flex items-start gap-2">
            <Activity size={15} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
              انتظام سداد الالتزامات يؤثر مباشرة على مؤشر النبض المالي.
            </p>
          </div>
          <button onClick={() => navigate("setup-budget")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            التالي
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Budget Page
// ─────────────────────────────────────────────────────────────────
function SetupBudgetPage({ navigate }: { navigate: (p: Page) => void }) {
  const categories = [
    { key: "food", label: "الطعام والمطاعم", icon: ShoppingCart, color: "#F59E0B" },
    { key: "transport", label: "المواصلات", icon: MapPin, color: "#0EA5E9" },
    { key: "shopping", label: "التسوق", icon: ShoppingCart, color: "#EC4899" },
    { key: "entertainment", label: "الترفيه", icon: Star, color: "#8B5CF6" },
    { key: "bills", label: "الفواتير", icon: Zap, color: "#64748B" },
    { key: "health", label: "الصحة", icon: Heart, color: "#DC2626" },
    { key: "education", label: "التعليم", icon: BrainCircuit, color: "#16A34A" },
    { key: "other", label: "أخرى", icon: Settings, color: "#94A3B8" },
  ];
  const [values, setValues] = useState<Record<string, string>>({});
  const total = Object.values(values).reduce((acc, v) => acc + (parseFloat(v) || 0), 0);
  return (
    <PageWrapper showBack onBack={() => navigate("setup-commitments")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={3} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>ميزانيتك الشهرية</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>حدد المبلغ المناسب لكل فئة</p>
          </div>
          <div className="flex flex-col gap-3 mb-4">
            {categories.map(cat => (
              <div key={cat.key} className="flex items-center gap-3 bg-slate-50 rounded-2xl px-4 py-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: cat.color + "18" }}>
                  <cat.icon size={16} style={{ color: cat.color }} />
                </div>
                <span className="text-sm font-semibold text-slate-700 flex-1" style={{ fontFamily: "Tajawal, sans-serif" }}>{cat.label}</span>
                <input type="number" placeholder="0"
                  value={values[cat.key] || ""}
                  onChange={e => setValues(v => ({ ...v, [cat.key]: e.target.value }))}
                  className="w-24 bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-sm text-slate-800 text-center focus:outline-none focus:border-blue-400 transition-all"
                  style={{ fontFamily: "Cairo, sans-serif" }} />
              </div>
            ))}
          </div>
          {total > 0 && (
            <div className="bg-gradient-to-l from-blue-600 to-green-600 rounded-2xl p-3 mb-4 flex items-center justify-between">
              <span className="text-white text-sm font-semibold" style={{ fontFamily: "Tajawal, sans-serif" }}>إجمالي الميزانية المحددة</span>
              <span className="text-white font-black text-lg" style={{ fontFamily: "Cairo, sans-serif" }}>{total.toLocaleString("ar-SA")} ر.س</span>
            </div>
          )}
          <button onClick={() => navigate("setup-goals")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            التالي
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Goals Page
// ─────────────────────────────────────────────────────────────────
function SetupGoalsPage({ navigate }: { navigate: (p: Page) => void }) {
  const goals = [
    { key: "save", label: "ادخار", icon: PiggyBank, color: "#16A34A" },
    { key: "emergency", label: "صندوق طوارئ", icon: Shield, color: "#DC2626" },
    { key: "car", label: "شراء سيارة", icon: Zap, color: "#0EA5E9" },
    { key: "home", label: "شراء منزل", icon: Home, color: "#1D4ED8" },
    { key: "invest", label: "استثمار", icon: TrendingUp, color: "#8B5CF6" },
    { key: "debt", label: "سداد التزامات", icon: CreditCard, color: "#F59E0B" },
    { key: "reduce", label: "تقليل المصاريف", icon: TrendingDown, color: "#64748B" },
  ];
  const [selected, setSelected] = useState<string[]>([]);
  const [amount, setAmount] = useState("");
  const [months, setMonths] = useState("");
  const toggleGoal = (key: string) =>
    setSelected(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]);
  return (
    <PageWrapper showBack onBack={() => navigate("setup-budget")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={3} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>ما أهدافك المالية؟</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>اختر هدفًا أو أكثر لمتابعة تحقيقه</p>
          </div>
          <div className="grid grid-cols-2 gap-2 mb-5">
            {goals.map(goal => {
              const isSelected = selected.includes(goal.key);
              return (
                <button key={goal.key} onClick={() => toggleGoal(goal.key)}
                  className={`flex items-center gap-2.5 p-3 rounded-2xl border-2 transition-all text-right ${isSelected ? "border-blue-500 bg-blue-50" : "border-slate-200 bg-slate-50 hover:bg-slate-100"}`}>
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: goal.color + "20" }}>
                    <goal.icon size={15} style={{ color: goal.color }} />
                  </div>
                  <span className={`text-sm font-semibold ${isSelected ? "text-blue-700" : "text-slate-700"}`}
                    style={{ fontFamily: "Tajawal, sans-serif" }}>{goal.label}</span>
                </button>
              );
            })}
          </div>
          {selected.length > 0 && (
            <div className="bg-slate-50 rounded-2xl p-4 mb-5">
              <p className="text-sm font-bold text-slate-700 mb-3" style={{ fontFamily: "Cairo, sans-serif" }}>تفاصيل الهدف الرئيسي</p>
              <div className="flex flex-col gap-3">
                <FormField label="مبلغ الهدف (ريال)" type="number" placeholder="500" icon={Wallet} value={amount} onChange={setAmount} />
                <FormField label="المدة المتوقعة (شهر)" type="number" placeholder="12" icon={Clock} value={months} onChange={setMonths}
                  hint={amount && months ? `المبلغ الشهري المطلوب: ${Math.ceil(parseFloat(amount) / parseFloat(months))} ريال` : undefined} />
              </div>
            </div>
          )}
          <button onClick={() => navigate("setup-bank")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            التالي
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Setup Bank Connection Page
// ─────────────────────────────────────────────────────────────────
function SetupBankPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <PageWrapper showBack onBack={() => navigate("setup-goals")}>
      <div className="w-full max-w-lg">
        <OnboardingProgress current={4} />
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center text-3xl shadow-sm"
              style={{ background: "linear-gradient(135deg,#EFF6FF,#F0FDF4)" }}>🏦</div>
            <h1 className="text-2xl font-black text-slate-900 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>اربط حسابك البنكي</h1>
            <p className="text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>اربط حسابك في بنك الإنماء لتحليل معاملاتك بدقة</p>
          </div>
          <div className="bg-slate-50 rounded-2xl p-4 mb-6">
            <p className="text-xs font-bold text-slate-600 mb-3 text-center" style={{ fontFamily: "Cairo, sans-serif" }}>ضمانات الأمان والخصوصية</p>
            <div className="grid grid-cols-1 gap-2">
              {[
                { icon: Shield, color: "#1D4ED8", text: "اتصال آمن ومشفر بمعايير بنكية" },
                { icon: Lock, color: "#16A34A", text: "خصوصية كاملة — بياناتك لا تُشارك أبدًا" },
                { icon: Eye, color: "#7C3AED", text: "تحليل ذكي للمعاملات فقط، دون وصول للأموال" },
                { icon: Settings, color: "#F59E0B", text: "يمكنك إيقاف الربط في أي وقت" },
              ].map(item => (
                <div key={item.text} className="flex items-center gap-3 bg-white rounded-xl p-3">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: item.color + "15" }}>
                    <item.icon size={14} style={{ color: item.color }} />
                  </div>
                  <span className="text-xs text-slate-600" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.text}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <button onClick={() => navigate("analyzing")}
              className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg flex items-center justify-center gap-2"
              style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
              <Building2 size={18} />
              ربط حساب الإنماء
            </button>
            <button onClick={() => navigate("analyzing")}
              className="w-full py-3 rounded-2xl font-semibold text-slate-500 bg-slate-50 border border-slate-200 text-sm hover:bg-slate-100 transition-all"
              style={{ fontFamily: "Tajawal, sans-serif" }}>
              تجربة ببيانات تجريبية
            </button>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Analyzing Page
// ─────────────────────────────────────────────────────────────────
function AnalyzingPage({ navigate }: { navigate: (p: Page) => void }) {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const steps = [
    "تحليل الدخل والإنفاق",
    "مقارنة المصروفات بالميزانية",
    "قياس نمو الادخار",
    "فحص الالتزامات القادمة",
    "إنشاء مؤشر النبض المالي",
  ];
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(interval); return 100; }
        return p + 2;
      });
    }, 60);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    setCurrentStep(Math.floor((progress / 100) * (steps.length - 1)));
  }, [progress]);
  useEffect(() => {
    if (progress >= 100) {
      const t = setTimeout(() => navigate("first-result"), 600);
      return () => clearTimeout(t);
    }
  }, [progress]);
  return (
    <PageWrapper>
      <div className="w-full max-w-lg">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-10 text-center">
          <div className="relative w-32 h-32 mx-auto mb-6">
            <svg width="128" height="128" className="rotate-[-90deg]">
              <circle cx="64" cy="64" r="52" fill="none" stroke="#E0EFFE" strokeWidth="10" />
              <circle cx="64" cy="64" r="52" fill="none" strokeWidth="10" strokeLinecap="round"
                stroke="url(#grad)" strokeDasharray={`${(progress / 100) * 2 * Math.PI * 52} ${2 * Math.PI * 52}`}
                style={{ transition: "stroke-dasharray 0.1s linear" }} />
              <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#1D4ED8" />
                  <stop offset="100%" stopColor="#16A34A" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-black" style={{ fontFamily: "Cairo, sans-serif", color: "#1D4ED8" }}>{progress}%</span>
            </div>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            جارٍ تحليل نبضك المالي...
          </h1>
          <p className="text-sm text-slate-400 mb-8" style={{ fontFamily: "Tajawal, sans-serif" }}>
            يُحلل الذكاء الاصطناعي بياناتك لإنشاء مؤشر نبض مالي دقيق
          </p>
          <div className="flex flex-col gap-2.5">
            {steps.map((step, idx) => (
              <div key={step}
                className={`flex items-center gap-3 rounded-2xl px-4 py-3 transition-all ${idx < currentStep ? "bg-green-50" : idx === currentStep ? "bg-blue-50" : "bg-slate-50"}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all
                  ${idx < currentStep ? "bg-green-500" : idx === currentStep ? "bg-blue-600" : "bg-slate-300"}`}>
                  {idx < currentStep ? <Check size={12} className="text-white" />
                    : idx === currentStep ? <Loader2 size={12} className="text-white animate-spin" />
                    : <span className="text-[10px] text-white font-bold">{idx + 1}</span>}
                </div>
                <span className={`text-sm font-semibold ${idx < currentStep ? "text-green-700" : idx === currentStep ? "text-blue-700" : "text-slate-400"}`}
                  style={{ fontFamily: "Tajawal, sans-serif" }}>
                  {step}
                </span>
                {idx < currentStep && <Check size={14} className="text-green-500 mr-auto" />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: First Result Page
// ─────────────────────────────────────────────────────────────────
function FirstResultPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <PageWrapper>
      <div className="w-full max-w-lg">
        <div className="text-center mb-6">
          <GradientBadge><Sparkles size={14} /> مؤشر نبض جاهز!</GradientBadge>
        </div>
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
          <h1 className="text-2xl font-black text-slate-900 text-center mb-6" style={{ fontFamily: "Cairo, sans-serif" }}>
            مؤشر نبضك المالي جاهز
          </h1>
          <div className="flex justify-center mb-3">
            <PulseGauge value={78} size={180} />
          </div>
          <div className="text-center mb-4">
            <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-green-100 text-green-700 font-bold text-sm">
              <CheckCircle size={14} />
              مستقر ماليًا
            </span>
          </div>
          <div className="px-4 py-3 bg-slate-50 rounded-2xl mb-6 text-center">
            <p className="text-sm text-slate-600 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
              وضعك المالي جيد، لكن يمكن تحسينه من خلال تقليل الإنفاق على بعض الفئات وزيادة الادخار.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-3 mb-6">
            <div className="flex items-center gap-3 bg-green-50 rounded-2xl p-4">
              <div className="w-9 h-9 rounded-xl bg-green-100 flex items-center justify-center"><CheckCircle size={18} className="text-green-600" /></div>
              <div>
                <p className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>أقوى نقطة</p>
                <p className="text-sm font-bold text-green-700" style={{ fontFamily: "Cairo, sans-serif" }}>انتظام سداد الالتزامات</p>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-amber-50 rounded-2xl p-4">
              <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center"><AlertTriangle size={18} className="text-amber-500" /></div>
              <div>
                <p className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>يحتاج تحسين</p>
                <p className="text-sm font-bold text-amber-700" style={{ fontFamily: "Cairo, sans-serif" }}>الإنفاق على المطاعم</p>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-blue-50 rounded-2xl p-4">
              <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center"><PiggyBank size={18} className="text-blue-600" /></div>
              <div>
                <p className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>فرصة توفير</p>
                <p className="text-sm font-bold text-blue-700" style={{ fontFamily: "Cairo, sans-serif" }}>240 ريال هذا الشهر</p>
              </div>
            </div>
          </div>
          <button onClick={() => navigate("dashboard")}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition-all hover:shadow-lg flex items-center justify-center gap-2"
            style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
            <LayoutDashboard size={18} />
            الدخول إلى لوحة نبض
          </button>
        </div>
      </div>
    </PageWrapper>
  );
}

// ─────────────────────────────────────────────────────────────────
// NEW: Dashboard Page
// ─────────────────────────────────────────────────────────────────
const predictionData = [
  { day: "اليوم", value: 78 },
  { day: "غدًا", value: 77 },
  { day: "+2", value: 76 },
  { day: "+3", value: 75 },
  { day: "+4", value: 74 },
  { day: "+5", value: 72 },
  { day: "+6", value: 71 },
  { day: "+7", value: 70 },
];

function DashboardPage({ navigate }: { navigate: (p: Page) => void }) {
  const [activeTab, setActiveTab] = useState("home");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [simValue, setSimValue] = useState(350);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([
    { from: "user", text: "هل أقدر أشتري الآن؟" },
    { from: "bot", text: "إذا اشتريت الآن فسينخفض مؤشر النبض إلى 72. يفضل الانتظار حتى نهاية الأسبوع أو تقليل الإنفاق في فئة المطاعم." },
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const afterPurchase = Math.max(60, 78 - Math.round((simValue / 350) * 6));

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chatMessages]);

  const sendChat = () => {
    if (!chatInput.trim()) return;
    const msg = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { from: "user", text: msg },
      { from: "bot", text: "بناءً على بياناتك الحالية، هذا الإنفاق سيؤثر على مؤشرك. أنصحك بمراجعة ميزانيتك الأسبوعية للمطاعم أولاً." }]);
  };

  const navItems = [
    { key: "home", icon: Home, label: "الرئيسية" },
    { key: "pulse", icon: Activity, label: "مؤشر النبض" },
    { key: "budget", icon: Wallet, label: "الميزانية" },
    { key: "alerts", icon: Bell, label: "التنبيهات" },
    { key: "simulation", icon: FlaskConical, label: "المحاكاة" },
    { key: "assistant", icon: Bot, label: "المساعد الذكي" },
    { key: "community", icon: Users, label: "مجتمع نبض" },
    { key: "settings", icon: Settings, label: "الإعدادات" },
  ];

  const DashboardHome = () => (
    <div className="flex flex-col gap-6">
      {/* Top row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pulse Gauge Card */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-slate-800" style={{ fontFamily: "Cairo, sans-serif" }}>مؤشر النبض المالي</h3>
            <span className="text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-semibold">مستقر ماليًا</span>
          </div>
          <div className="flex justify-center"><PulseGauge value={78} size={150} /></div>
          <div className="mt-2"><HeartbeatLine color="#1D4ED8" /></div>
          <p className="text-xs text-slate-400 text-center mt-2" style={{ fontFamily: "Tajawal, sans-serif" }}>
            تم تحديث المؤشر اليوم بناءً على آخر معاملاتك.
          </p>
        </div>

        {/* Financial Summary */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "Cairo, sans-serif" }}>ملخص مالي سريع</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { label: "الدخل الشهري", value: "7,500", unit: "ر.س", color: "#16A34A", icon: TrendingUp },
              { label: "الإنفاق الحالي", value: "3,920", unit: "ر.س", color: "#F59E0B", icon: ShoppingCart },
              { label: "الالتزامات القادمة", value: "1,200", unit: "ر.س", color: "#DC2626", icon: CreditCard },
              { label: "نسبة الادخار", value: "18", unit: "%", color: "#1D4ED8", icon: PiggyBank },
              { label: "المبلغ الآمن اليومي", value: "64", unit: "ر.س", color: "#7C3AED", icon: Calculator },
              { label: "حالة الميزانية", value: "آمن", unit: "✓", color: "#16A34A", icon: CheckCircle },
            ].map(item => (
              <div key={item.label} className="rounded-2xl p-3.5" style={{ background: item.color + "0D" }}>
                <div className="flex items-center gap-1.5 mb-2">
                  <item.icon size={14} style={{ color: item.color }} />
                  <span className="text-xs text-slate-500" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.label}</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-black" style={{ color: item.color, fontFamily: "Cairo, sans-serif" }}>{item.value}</span>
                  <span className="text-xs font-semibold" style={{ color: item.color }}>{item.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Savings Goal + Prediction */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <PiggyBank size={18} className="text-green-500" /> هدفك هذا الشهر
          </h3>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl font-black text-green-600" style={{ fontFamily: "Cairo, sans-serif" }}>310</span>
            <span className="text-slate-400 text-sm">/ 500 ر.س</span>
          </div>
          <p className="text-xs text-slate-400 mb-3" style={{ fontFamily: "Tajawal, sans-serif" }}>ادخار 500 ريال هذا الشهر</p>
          <div className="h-3 bg-slate-100 rounded-full overflow-hidden mb-2">
            <div className="h-full rounded-full" style={{ width: "62%", background: "linear-gradient(90deg,#1D4ED8,#16A34A)" }} />
          </div>
          <div className="flex justify-between text-xs text-slate-400">
            <span>62% مكتمل</span>
            <span>باقي 190 ر.س</span>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-1 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <Sparkles size={18} className="text-blue-500" /> توقع الأيام القادمة
          </h3>
          <p className="text-xs text-slate-400 mb-3" style={{ fontFamily: "Tajawal, sans-serif" }}>
            إذا استمر نمط الإنفاق، سينخفض المؤشر من 78 إلى 70 خلال 7 أيام
          </p>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={predictionData} margin={{ top: 4, right: 8, left: 8, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="day" tick={{ fontSize: 10, fontFamily: "Tajawal, sans-serif", fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis domain={[65, 85]} tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={28} />
              <Tooltip contentStyle={{ fontFamily: "Cairo, sans-serif", fontSize: 12, borderRadius: 12, border: "1px solid #E2E8F0" }} />
              <ReferenceLine y={78} stroke="#1D4ED8" strokeDasharray="4 4" strokeWidth={1} />
              <Line type="monotone" dataKey="value" stroke="url(#lineGrad)" strokeWidth={2.5} dot={{ r: 3, fill: "#1D4ED8" }} />
              <defs>
                <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#1D4ED8" />
                  <stop offset="100%" stopColor="#DC2626" />
                </linearGradient>
              </defs>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alerts */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <Bell size={18} className="text-blue-500" /> التنبيهات الذكية
          </h3>
          <button onClick={() => setActiveTab("alerts")} className="text-xs text-blue-600 font-semibold hover:underline">عرض الكل</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <AlertCard icon={TrendingUp} color="#DC2626" text="ارتفع إنفاقك على المطاعم هذا الأسبوع بنسبة 22%" time="قبل لحظات" />
          <AlertCard icon={Bell} color="#7C3AED" text="لديك اشتراك غير مستخدم منذ 3 أشهر — وفّر 49 ر.س شهريًا" time="منذ ساعتين" />
          <AlertCard icon={ShoppingCart} color="#F59E0B" text="اقتربت من تجاوز ميزانية التسوق، تبقى 120 ر.س" time="اليوم 10:30 ص" />
          <AlertCard icon={PiggyBank} color="#16A34A" text="يمكنك توفير 240 ر.س هذا الشهر إذا خففت الطلبات" time="اليوم 08:00 ص" />
        </div>
      </div>

      {/* Simulation + Assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Simulation */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <FlaskConical size={18} className="text-pink-500" /> قبل أن تشتري، اسأل نبض
          </h3>
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-slate-500">قيمة الشراء</span>
              <span className="text-xl font-black text-blue-700" style={{ fontFamily: "Cairo, sans-serif" }}>{simValue} ر.س</span>
            </div>
            <input type="range" min={50} max={2000} step={50} value={simValue}
              onChange={e => setSimValue(Number(e.target.value))}
              className="w-full h-2 rounded-full appearance-none cursor-pointer"
              style={{ background: `linear-gradient(to left, #1D4ED8 ${(simValue / 2000) * 100}%, #E2E8F0 ${(simValue / 2000) * 100}%)` }} />
          </div>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-green-50 rounded-2xl p-3 text-center border border-green-100">
              <div className="text-xs text-slate-400 mb-1">المؤشر الحالي</div>
              <div className="text-3xl font-black text-green-600" style={{ fontFamily: "Cairo, sans-serif" }}>78</div>
            </div>
            <div className="bg-amber-50 rounded-2xl p-3 text-center border border-amber-100">
              <div className="text-xs text-slate-400 mb-1">بعد الشراء</div>
              <div className="text-3xl font-black" style={{ fontFamily: "Cairo, sans-serif", color: afterPurchase >= 72 ? "#16A34A" : afterPurchase >= 65 ? "#F59E0B" : "#DC2626" }}>{afterPurchase}</div>
            </div>
          </div>
          <div className="rounded-2xl p-3 text-white mb-3" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
            <p className="text-xs opacity-90" style={{ fontFamily: "Tajawal, sans-serif" }}>
              {afterPurchase >= 74 ? "الشراء آمن ولن يؤثر على أهدافك." : afterPurchase >= 68 ? "يُفضّل تأجيل الشراء 5 أيام للحفاظ على هدفك الادخاري." : "هذا الشراء سيؤثر بشكل ملحوظ. ننصح بالتأجيل."}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button className="py-2.5 rounded-xl text-xs font-bold text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
              تنفيذ الشراء
            </button>
            <button className="py-2.5 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors" style={{ fontFamily: "Cairo, sans-serif" }}>
              تأجيل القرار
            </button>
          </div>
        </div>

        {/* AI Assistant */}
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-5 py-4 flex items-center gap-3 text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center"><Bot size={16} className="text-white" /></div>
            <div>
              <div className="font-bold text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>مساعد نبض الذكي</div>
              <div className="text-xs opacity-75">متصل الآن</div>
            </div>
            <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse mr-auto" />
          </div>
          <div className="h-52 overflow-y-auto px-4 py-3 flex flex-col gap-2.5">
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.from === "user" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed ${msg.from === "user" ? "bg-slate-100 text-slate-800 rounded-tr-sm" : "text-white rounded-tl-sm"}`}
                  style={{ background: msg.from === "bot" ? "linear-gradient(135deg,#1D4ED8,#16A34A)" : undefined, fontFamily: "Tajawal, sans-serif" }}>
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          <div className="px-3 py-2.5 border-t border-slate-100 flex items-center gap-2">
            <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && sendChat()}
              placeholder="اسأل نبض..."
              className="flex-1 bg-slate-50 rounded-xl px-3 py-2 text-xs outline-none border border-slate-200 focus:border-blue-300 transition-colors"
              style={{ fontFamily: "Tajawal, sans-serif" }} />
            <button onClick={sendChat} className="w-8 h-8 rounded-xl flex items-center justify-center text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
              <Send size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Factors + Community */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Factors */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <BarChart3 size={18} className="text-blue-500" /> تحليل عوامل المؤشر
          </h3>
          {[
            { label: "الإنفاق مقارنة بالدخل", value: 82, status: "جيد", color: "#16A34A" },
            { label: "الالتزام بالميزانية", value: 65, status: "متوسط", color: "#F59E0B" },
            { label: "نمو المدخرات", value: 78, status: "جيد", color: "#16A34A" },
            { label: "السلوك الشرائي اللحظي", value: 55, status: "يحتاج انتباه", color: "#F59E0B" },
            { label: "انتظام سداد الالتزامات", value: 95, status: "ممتاز", color: "#16A34A" },
          ].map(item => (
            <div key={item.label} className="mb-3 last:mb-0">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-semibold text-slate-700" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.label}</span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ color: item.color, background: item.color + "15" }}>{item.status}</span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${item.value}%`, background: item.color }} />
              </div>
            </div>
          ))}
        </div>

        {/* Community */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-1 flex items-center gap-2" style={{ fontFamily: "Cairo, sans-serif" }}>
            <Users size={18} className="text-blue-500" /> مجتمع نبض
          </h3>
          <p className="text-xs text-slate-400 mb-4" style={{ fontFamily: "Tajawal, sans-serif" }}>
            قارن أداءك مع أشخاص مشابهين لك في العمر والدخل والمدينة، مع الحفاظ الكامل على الخصوصية.
          </p>
          <div className="flex flex-col gap-3 mb-4">
            {[
              { label: "مؤشر نبضك", value: 78, color: "#1D4ED8", highlight: true },
              { label: "متوسط الأشخاص المشابهين", value: 71, color: "#94A3B8", highlight: false },
              { label: "أعلى 10%", value: 88, color: "#16A34A", highlight: false },
            ].map(item => (
              <div key={item.label} className={`rounded-2xl px-4 py-3 flex items-center gap-3 ${item.highlight ? "bg-blue-50 border border-blue-200" : "bg-slate-50"}`}>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-semibold text-slate-700" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.label}</span>
                    <span className="text-sm font-black" style={{ color: item.color, fontFamily: "Cairo, sans-serif" }}>{item.value}</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${item.value}%`, background: item.color }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-green-50 rounded-2xl p-3 flex items-center gap-2">
            <Shield size={14} className="text-green-600 flex-shrink-0" />
            <p className="text-xs text-green-700" style={{ fontFamily: "Tajawal, sans-serif" }}>لا تتم مشاركة أي بيانات شخصية.</p>
          </div>
        </div>
      </div>
    </div>
  );

  const tabContent: Record<string, React.ReactNode> = {
    home: <DashboardHome />,
    pulse: (
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 text-center">
        <GradientBadge><Activity size={14} /> مؤشر النبض المالي</GradientBadge>
        <div className="flex justify-center my-8"><PulseGauge value={78} size={220} /></div>
        <div className="flex justify-center mb-4"><HeartbeatLine color="#1D4ED8" /></div>
        <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto mt-6">
          {[{ label: "هذا الأسبوع", value: "+3", color: "#16A34A" }, { label: "هذا الشهر", value: "+8", color: "#16A34A" }, { label: "التوقع (7 أيام)", value: "-8", color: "#DC2626" }].map(s => (
            <div key={s.label} className="bg-slate-50 rounded-2xl p-3 text-center">
              <div className="text-xl font-black mb-1" style={{ color: s.color, fontFamily: "Cairo, sans-serif" }}>{s.value}</div>
              <div className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    ),
    budget: (
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <h2 className="text-2xl font-black text-slate-900 mb-6" style={{ fontFamily: "Cairo, sans-serif" }}>الميزانية الشهرية</h2>
        {[
          { label: "الطعام والمطاعم", budget: 800, spent: 920, color: "#F59E0B" },
          { label: "المواصلات", budget: 400, spent: 280, color: "#0EA5E9" },
          { label: "التسوق", budget: 600, spent: 540, color: "#EC4899" },
          { label: "الترفيه", budget: 300, spent: 180, color: "#8B5CF6" },
          { label: "الصحة", budget: 200, spent: 150, color: "#16A34A" },
          { label: "الفواتير", budget: 500, spent: 500, color: "#64748B" },
        ].map(cat => {
          const pct = Math.min(100, (cat.spent / cat.budget) * 100);
          const over = cat.spent > cat.budget;
          return (
            <div key={cat.label} className="mb-5 last:mb-0">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-sm font-semibold text-slate-700" style={{ fontFamily: "Tajawal, sans-serif" }}>{cat.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold" style={{ color: over ? "#DC2626" : "#16A34A", fontFamily: "Cairo, sans-serif" }}>{cat.spent.toLocaleString("ar-SA")}</span>
                  <span className="text-xs text-slate-400">/ {cat.budget.toLocaleString("ar-SA")} ر.س</span>
                </div>
              </div>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: over ? "#DC2626" : cat.color }} />
              </div>
              {over && <p className="text-xs text-red-500 mt-0.5" style={{ fontFamily: "Tajawal, sans-serif" }}>تجاوزت الميزانية بـ {cat.spent - cat.budget} ر.س</p>}
            </div>
          );
        })}
      </div>
    ),
    alerts: (
      <div className="flex flex-col gap-4">
        <h2 className="text-2xl font-black text-slate-900" style={{ fontFamily: "Cairo, sans-serif" }}>التنبيهات الذكية</h2>
        <AlertCard icon={TrendingUp} color="#DC2626" text="ارتفع إنفاقك على المطاعم هذا الأسبوع بنسبة 22% عن المعتاد" time="قبل لحظات" />
        <AlertCard icon={Bell} color="#7C3AED" text="لديك اشتراك غير مستخدم منذ 3 أشهر — وفّر 49 ر.س شهريًا بإلغائه" time="منذ ساعتين" />
        <AlertCard icon={ShoppingCart} color="#F59E0B" text="اقتربت من تجاوز ميزانية التسوق المحددة، تبقى 120 ر.س" time="اليوم 10:30 ص" />
        <AlertCard icon={PiggyBank} color="#16A34A" text="يمكنك توفير 240 ر.س هذا الشهر إذا خففت الإنفاق على الطلبات" time="اليوم 08:00 ص" />
        <AlertCard icon={AlertTriangle} color="#0EA5E9" text="موعد سداد قسطك الشهري بعد 3 أيام — تأكد من توفر الرصيد" time="أمس" />
        <AlertCard icon={Sparkles} color="#16A34A" text="أحسنت! حافظت على ميزانية المواصلات هذا الشهر بالكامل" time="أمس" />
      </div>
    ),
    simulation: (
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 max-w-xl">
        <h2 className="text-2xl font-black text-slate-900 mb-6" style={{ fontFamily: "Cairo, sans-serif" }}>محاكاة القرارات المالية</h2>
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <label className="font-semibold text-slate-700 text-sm">قيمة الشراء المرتقب</label>
            <span className="text-2xl font-black text-blue-700" style={{ fontFamily: "Cairo, sans-serif" }}>{simValue} ر.س</span>
          </div>
          <input type="range" min={50} max={3000} step={50} value={simValue} onChange={e => setSimValue(Number(e.target.value))}
            className="w-full h-2.5 rounded-full appearance-none cursor-pointer"
            style={{ background: `linear-gradient(to left, #1D4ED8 ${(simValue / 3000) * 100}%, #E2E8F0 ${(simValue / 3000) * 100}%)` }} />
          <div className="flex justify-between text-xs text-slate-400 mt-1"><span>50 ر.س</span><span>3,000 ر.س</span></div>
        </div>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-green-50 rounded-2xl p-5 text-center border border-green-100">
            <div className="text-xs text-slate-400 mb-2">المؤشر الحالي</div>
            <div className="text-5xl font-black text-green-600" style={{ fontFamily: "Cairo, sans-serif" }}>78</div>
          </div>
          <div className="bg-amber-50 rounded-2xl p-5 text-center border border-amber-100">
            <div className="text-xs text-slate-400 mb-2">بعد الشراء</div>
            <div className="text-5xl font-black" style={{ fontFamily: "Cairo, sans-serif", color: afterPurchase >= 72 ? "#16A34A" : "#F59E0B" }}>{afterPurchase}</div>
          </div>
        </div>
        <div className="rounded-2xl p-5 text-white mb-4" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
          <div className="flex items-center gap-2 mb-2"><Sparkles size={16} /><span className="font-bold">توصية نبض</span></div>
          <p style={{ fontFamily: "Tajawal, sans-serif" }}>
            {afterPurchase >= 74 ? "الشراء آمن تمامًا ولن يؤثر على أهدافك الادخارية. تفضل!" : "يُفضّل تأجيل الشراء 5 أيام أو تقليل الإنفاق على المطاعم هذا الأسبوع."}
          </p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button className="py-3 rounded-2xl font-bold text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>تنفيذ الشراء</button>
          <button className="py-3 rounded-2xl font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors" style={{ fontFamily: "Cairo, sans-serif" }}>تأجيل القرار</button>
        </div>
      </div>
    ),
    assistant: (
      <div className="max-w-xl">
        <h2 className="text-2xl font-black text-slate-900 mb-4" style={{ fontFamily: "Cairo, sans-serif" }}>المساعد المالي الذكي</h2>
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-5 py-4 flex items-center gap-3 text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center"><Bot size={20} className="text-white" /></div>
            <div>
              <div className="font-bold" style={{ fontFamily: "Cairo, sans-serif" }}>مساعد نبض</div>
              <div className="text-xs opacity-75">يعرف كل شيء عن ماليتك</div>
            </div>
            <div className="w-2.5 h-2.5 bg-green-300 rounded-full animate-pulse mr-auto" />
          </div>
          <div className="h-80 overflow-y-auto px-5 py-4 flex flex-col gap-3">
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.from === "user" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${msg.from === "user" ? "bg-slate-100 text-slate-800 rounded-tr-sm" : "text-white rounded-tl-sm"}`}
                  style={{ background: msg.from === "bot" ? "linear-gradient(135deg,#1D4ED8,#16A34A)" : undefined, fontFamily: "Tajawal, sans-serif" }}>
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-2">
            <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && sendChat()}
              placeholder="اسأل نبض عن وضعك المالي..."
              className="flex-1 bg-slate-50 rounded-xl px-4 py-2.5 text-sm outline-none border border-slate-200 focus:border-blue-300 transition-colors"
              style={{ fontFamily: "Tajawal, sans-serif" }} />
            <button onClick={sendChat} className="w-10 h-10 rounded-xl flex items-center justify-center text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    ),
    community: (
      <div className="max-w-2xl">
        <h2 className="text-2xl font-black text-slate-900 mb-6" style={{ fontFamily: "Cairo, sans-serif" }}>مجتمع نبض</h2>
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 mb-5">
          <div className="flex items-center justify-between mb-4">
            <span className="font-bold text-slate-800" style={{ fontFamily: "Cairo, sans-serif" }}>مقارنتك مع المجموعة المشابهة</span>
            <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">الرياض · 25-35 سنة</span>
          </div>
          {[
            { label: "مؤشر النبض المالي", mine: 78, avg: 71, top: 88 },
            { label: "متوسط الادخار الشهري (%)", mine: 18, avg: 14, top: 28 },
            { label: "الالتزام بالميزانية (%)", mine: 72, avg: 61, top: 89 },
          ].map(item => (
            <div key={item.label} className="mb-5 last:mb-0">
              <div className="flex justify-between items-center mb-2 text-xs text-slate-500">
                <span className="font-semibold">{item.label}</span>
                <div className="flex gap-3">
                  <span className="text-blue-700 font-bold">أنت: {item.mine}</span>
                  <span>المجموعة: {item.avg}</span>
                  <span className="text-green-600">أعلى 10%: {item.top}</span>
                </div>
              </div>
              <div className="relative h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="absolute top-0 h-full rounded-full opacity-30" style={{ width: `${item.avg}%`, background: "#64748B" }} />
                <div className="absolute top-0 h-full rounded-full" style={{ width: `${item.mine}%`, background: "linear-gradient(90deg,#1D4ED8,#16A34A)" }} />
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          {[
            { icon: Shield, color: "#1D4ED8", bg: "#EFF6FF", title: "مجهول وآمن", desc: "لا كشف هوية أبدًا" },
            { icon: Users, color: "#16A34A", bg: "#F0FDF4", title: "مشابهون لك", desc: "عمر، دخل، مدينة" },
            { icon: Star, color: "#F59E0B", bg: "#FFFBEB", title: "تحفيز للتحسن", desc: "اعرف أين أنت" },
          ].map(item => (
            <div key={item.title} className="rounded-2xl p-4 text-center" style={{ background: item.bg }}>
              <item.icon size={22} style={{ color: item.color }} className="mx-auto mb-2" />
              <div className="font-bold text-sm text-slate-800 mb-1" style={{ fontFamily: "Cairo, sans-serif" }}>{item.title}</div>
              <div className="text-xs text-slate-500" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</div>
            </div>
          ))}
        </div>
      </div>
    ),
    settings: (
      <div className="max-w-lg">
        <h2 className="text-2xl font-black text-slate-900 mb-6" style={{ fontFamily: "Cairo, sans-serif" }}>الإعدادات</h2>
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-100">
          {[
            { icon: User, label: "الملف الشخصي", desc: "أحمد عبدالله · الرياض" },
            { icon: Bell, label: "إعدادات التنبيهات", desc: "مفعّلة — 4 تنبيهات اليوم" },
            { icon: Shield, label: "الخصوصية والأمان", desc: "البيانات مشفرة ومحمية" },
            { icon: Building2, label: "الحسابات البنكية المربوطة", desc: "بنك الإنماء — نشط" },
            { icon: Users, label: "مجتمع نبض", desc: "مفعّل — مشاركة مجهولة" },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50 transition-colors cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                <item.icon size={18} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-slate-800 text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>{item.label}</div>
                <div className="text-xs text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</div>
              </div>
              <ChevronRight size={16} className="text-slate-300 rotate-180" />
            </div>
          ))}
        </div>
        <div className="mt-4">
          <button onClick={() => navigate("landing")}
            className="w-full py-3 rounded-2xl text-sm font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200 transition-colors"
            style={{ fontFamily: "Tajawal, sans-serif" }}>
            العودة إلى الصفحة الرئيسية
          </button>
        </div>
      </div>
    ),
  };

  return (
    <div dir="rtl" className="min-h-screen flex flex-col" style={{ background: "#F7FBFC", fontFamily: "Tajawal, sans-serif" }}>
      {/* Dashboard Top Bar */}
      <div className="bg-white border-b border-slate-100 px-4 py-3 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100">
              <Menu size={20} />
            </button>
            <span className="text-xl">💓</span>
            <span className="font-black text-base" style={{ fontFamily: "Cairo, sans-serif", background: "linear-gradient(135deg,#1D4ED8,#16A34A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              نبض | Pulse
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-1.5">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-green-500 flex items-center justify-center">
                <span className="text-[10px] text-white font-bold">أح</span>
              </div>
              <span className="text-sm font-bold text-green-700 hidden sm:block" style={{ fontFamily: "Cairo, sans-serif" }}>78</span>
              <Activity size={14} className="text-green-500" />
            </div>
            <button className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center relative">
              <Bell size={16} className="text-slate-600" />
              <span className="absolute top-0.5 right-0.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-1 max-w-7xl mx-auto w-full">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? "flex" : "hidden"} lg:flex flex-col w-56 bg-white border-l border-slate-100 py-4 px-3 gap-1 sticky top-[57px] h-[calc(100vh-57px)] overflow-y-auto shrink-0`}>
          {navItems.map(item => (
            <button key={item.key} onClick={() => { setActiveTab(item.key); setSidebarOpen(false); }}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-semibold transition-all text-right ${activeTab === item.key ? "text-white shadow-sm" : "text-slate-600 hover:bg-slate-50"}`}
              style={activeTab === item.key ? { background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Tajawal, sans-serif" } : { fontFamily: "Tajawal, sans-serif" }}>
              <item.icon size={17} className={activeTab === item.key ? "text-white" : "text-slate-400"} />
              {item.label}
            </button>
          ))}
          <div className="mt-auto pt-4 border-t border-slate-100">
            <button onClick={() => navigate("landing")}
              className="flex items-center gap-2 px-3 py-2.5 rounded-2xl text-xs text-slate-400 hover:bg-slate-50 w-full transition-colors"
              style={{ fontFamily: "Tajawal, sans-serif" }}>
              <ArrowRight size={14} />
              العودة للرئيسية
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          {tabContent[activeTab] || <DashboardHome />}
        </main>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// LANDING PAGE (all existing content, unchanged)
// ─────────────────────────────────────────────────────────────────
function LandingPage({ navigate }: { navigate: (p: Page) => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [simulationValue, setSimulationValue] = useState(350);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([
    { from: "user", text: "هل أقدر أشتري الآن؟" },
    { from: "bot", text: "إذا اشتريت الآن فسينخفض مؤشر النبض إلى 72. يفضل الانتظار حتى نهاية الأسبوع أو تقليل الإنفاق في فئة المطاعم." },
  ]);
  const [scrolled, setScrolled] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chatMessages]);

  const afterPurchaseScore = Math.max(0, 78 - Math.round((simulationValue / 350) * 6));

  const sendChat = () => {
    if (!chatInput.trim()) return;
    const msg = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { from: "user", text: msg },
      { from: "bot", text: "بناءً على بياناتك الحالية، مؤشر النبض سيتأثر بهذا الإنفاق. أنصحك بمراجعة ميزانيتك الأسبوعية أولاً." }]);
  };

  const navLinks = [
    { label: "الرئيسية", href: "#hero" },
    { label: "المشكلة", href: "#problem" },
    { label: "الحل", href: "#solution" },
    { label: "المميزات", href: "#features" },
    { label: "الابتكار", href: "#innovation" },
    { label: "القيمة للبنك", href: "#bank-value" },
    { label: "الرؤية", href: "#vision" },
  ];

  return (
    <div dir="rtl" style={{ fontFamily: "Tajawal, sans-serif", background: "#F7FBFC", color: "#0F1923" }}>
      {/* ─────────────── NAVBAR ─────────────── */}
      <nav className={`fixed top-0 right-0 left-0 z-50 transition-all duration-300 ${scrolled ? "bg-white/95 backdrop-blur-md shadow-md" : "bg-transparent"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <a href="#hero" className="flex items-center gap-2">
              <span className="text-2xl">💓</span>
              <div className="flex items-center gap-1">
                <span className="text-xl font-black" style={{ fontFamily: "Cairo, sans-serif", background: "linear-gradient(135deg,#1D4ED8,#16A34A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>نبض</span>
                <span className="text-slate-400 text-sm font-medium">| Pulse</span>
              </div>
            </a>
            <div className="hidden lg:flex items-center gap-6">
              {navLinks.map(link => (
                <a key={link.href} href={link.href} className="text-sm text-slate-600 hover:text-blue-700 font-semibold transition-colors" style={{ fontFamily: "Tajawal, sans-serif" }}>{link.label}</a>
              ))}
            </div>
            <div className="hidden lg:flex items-center gap-3">
              <button onClick={() => navigate("auth")}
                className="px-5 py-2 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90 hover:shadow-lg"
                style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
                ابدأ الآن
              </button>
            </div>
            <button className="lg:hidden p-2 rounded-xl text-slate-600" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden bg-white border-t border-slate-100 px-4 py-4 flex flex-col gap-3 shadow-lg">
            {navLinks.map(link => (
              <a key={link.href} href={link.href} className="text-sm text-slate-700 font-semibold py-2 border-b border-slate-50" onClick={() => setMenuOpen(false)}>{link.label}</a>
            ))}
            <button onClick={() => { setMenuOpen(false); navigate("auth"); }}
              className="mt-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white text-center"
              style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
              ابدأ الآن
            </button>
          </div>
        )}
      </nav>

      {/* ─────────────── HERO ─────────────── */}
      <section id="hero" className="relative min-h-screen flex items-center overflow-hidden pt-16" style={{ background: "linear-gradient(160deg, #EFF6FF 0%, #F0FDF4 50%, #F7FBFC 100%)" }}>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #1D4ED8, transparent)" }} />
          <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #16A34A, transparent)" }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full opacity-5" style={{ background: "radial-gradient(circle, #1D4ED8, transparent)" }} />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="flex flex-col gap-6">
              <div className="flex justify-start">
                <GradientBadge><Activity size={14} />منصة ذكاء مالي متكاملة</GradientBadge>
              </div>
              <h1 className="text-5xl lg:text-6xl font-black text-slate-900 leading-[1.15]" style={{ fontFamily: "Cairo, sans-serif" }}>
                نبضك المالي
                <br />
                <span style={{ background: "linear-gradient(135deg, #1D4ED8 0%, #16A34A 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>في رقم واحد</span>
              </h1>
              <p className="text-lg text-slate-600 leading-relaxed max-w-lg" style={{ fontFamily: "Tajawal, sans-serif" }}>
                منصة ذكية تحوّل بياناتك المالية إلى مؤشر واضح من <strong className="text-blue-700">0 إلى 100</strong> يساعدك على فهم وضعك المالي الحالي، والتنبؤ بمستقبلك، واتخاذ قرارات أفضل قبل فوات الأوان.
              </p>
              <div className="flex flex-wrap gap-4">
                <button onClick={() => navigate("auth")}
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl text-white font-bold text-base transition-all hover:shadow-xl hover:scale-105"
                  style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", fontFamily: "Cairo, sans-serif" }}>
                  ابدأ الآن
                  <ArrowLeft size={18} />
                </button>
                <a href="#solution" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-white text-blue-700 font-bold text-base border border-blue-200 hover:bg-blue-50 transition-all" style={{ fontFamily: "Cairo, sans-serif" }}>
                  شاهد كيف يعمل
                  <ChevronDown size={18} />
                </a>
              </div>
              <div className="flex items-center gap-6 pt-2">
                <div className="flex items-center gap-1.5"><CheckCircle size={16} className="text-green-600" /><span className="text-sm text-slate-500">آمن ومشفر</span></div>
                <div className="flex items-center gap-1.5"><Shield size={16} className="text-blue-600" /><span className="text-sm text-slate-500">معيار بنكي</span></div>
                <div className="flex items-center gap-1.5"><BrainCircuit size={16} className="text-green-600" /><span className="text-sm text-slate-500">ذكاء اصطناعي</span></div>
              </div>
            </div>
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative w-full max-w-md rounded-3xl p-6 shadow-2xl border border-white/60" style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(12px)" }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">💓</span>
                    <span className="font-black text-slate-900" style={{ fontFamily: "Cairo, sans-serif" }}>نبض | Pulse</span>
                  </div>
                  <span className="text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-semibold">مستقر ماليًا</span>
                </div>
                <div className="flex flex-col items-center gap-2 py-2">
                  <PulseGauge value={78} size={160} />
                  <div className="flex items-center gap-1.5 text-slate-500 text-sm"><Activity size={14} className="text-blue-500" />مؤشر النبض المالي</div>
                </div>
                <div className="my-3 px-2"><HeartbeatLine color="#1D4ED8" /></div>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-blue-50 rounded-2xl p-3">
                    <div className="text-xs text-slate-500 mb-1">المبلغ الآمن اليومي</div>
                    <div className="text-xl font-black text-blue-700" style={{ fontFamily: "Cairo, sans-serif" }}>64 ر.س</div>
                  </div>
                  <div className="bg-green-50 rounded-2xl p-3">
                    <div className="text-xs text-slate-500 mb-1">هدف الادخار</div>
                    <div className="text-xl font-black text-green-700" style={{ fontFamily: "Cairo, sans-serif" }}>500 ر.س</div>
                  </div>
                </div>
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-slate-500 mb-1.5"><span>التقدم نحو هدف الادخار</span><span className="font-semibold text-green-600">68%</span></div>
                  <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: "68%", background: "linear-gradient(90deg, #1D4ED8, #16A34A)" }} />
                  </div>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-start gap-2.5 mb-3">
                  <AlertTriangle size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-amber-700 mb-0.5">تنبيه ذكي</p>
                    <p className="text-xs text-amber-600" style={{ fontFamily: "Tajawal, sans-serif" }}>ارتفع إنفاقك على المطاعم هذا الأسبوع بنسبة 22%</p>
                  </div>
                </div>
                <div className="bg-gradient-to-l from-blue-600 to-green-600 rounded-2xl p-3 text-white">
                  <div className="flex items-center gap-1.5 mb-1"><Sparkles size={13} /><span className="text-xs font-semibold opacity-90">توقع مستقبلي</span></div>
                  <p className="text-xs opacity-85" style={{ fontFamily: "Tajawal, sans-serif" }}>إذا استمر نمط الإنفاق الحالي، سينخفض المؤشر إلى <strong>72</strong> خلال 5 أيام</p>
                </div>
              </div>
              <div className="absolute -top-4 -left-4 bg-white rounded-2xl shadow-lg p-3 border border-slate-100 flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 flex items-center justify-center"><TrendingUp size={16} className="text-blue-600" /></div>
                <div><div className="text-xs font-black text-slate-900">+12 نقطة</div><div className="text-xs text-slate-400">هذا الأسبوع</div></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────── PROBLEM ─────────────── */}
      <section id="problem" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="المشكلة" title="لماذا الأدوات الحالية لا تكفي؟"
            subtitle="معظم التطبيقات المالية تعرض الإنفاق بعد حدوثه، بينما يحتاج المستخدم إلى التوجيه في لحظة اتخاذ القرار المالي." />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Clock, color: "#DC2626", bg: "#FEF2F2", title: "تحليل متأخر للإنفاق", desc: "تُعرض التقارير بعد انتهاء الشهر، ولا توجه المستخدم في اللحظات الحاسمة." },
              { icon: BarChart3, color: "#EA580C", bg: "#FFF7ED", title: "صعوبة فهم التقارير", desc: "جداول وأرقام معقدة تُربك المستخدم العادي وتجعل الفهم الفوري مستحيلاً." },
              { icon: Target, color: "#7C3AED", bg: "#F5F3FF", title: "غياب مؤشر واضح", desc: "لا يوجد رقم واحد واضح يعكس الوضع المالي الشامل بشكل مبسط وقابل للمتابعة." },
              { icon: Wallet, color: "#0369A1", bg: "#EFF6FF", title: "قرارات بدون توجيه", desc: "يتخذ المستخدم قرارات شرائية دون معرفة أثرها على صحته المالية المستقبلية." },
            ].map(item => (
              <div key={item.title} className="rounded-3xl p-6 border border-slate-100 hover:shadow-lg transition-shadow" style={{ background: item.bg }}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4" style={{ background: item.color + "20" }}>
                  <item.icon size={24} style={{ color: item.color }} />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>{item.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─────────────── SOLUTION ─────────────── */}
      <section id="solution" className="py-24" style={{ background: "linear-gradient(160deg, #EFF6FF 0%, #F0FDF4 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="الحل" title="ذكاء اصطناعي يفهم ماليتك"
            subtitle="يوفر نبض مؤشرًا ماليًا ذكيًا يعتمد على الذكاء الاصطناعي لتحليل بياناتك البنكية وإنشاء درجة مالية يومية من 0 إلى 100." />
          <div className="flex flex-col lg:flex-row items-center justify-center gap-4 lg:gap-2 flex-wrap">
            {[
              { icon: CreditCard, label: "بيانات بنكية", color: "#1D4ED8", bg: "#EFF6FF" },
              { icon: BrainCircuit, label: "ذكاء اصطناعي", color: "#7C3AED", bg: "#F5F3FF" },
              { icon: BarChart3, label: "تحليل السلوك", color: "#0369A1", bg: "#E0F2FE" },
              { icon: Activity, label: "مؤشر النبض", color: "#16A34A", bg: "#F0FDF4" },
              { icon: Bell, label: "توصيات ذكية", color: "#F59E0B", bg: "#FFFBEB" },
            ].map((step, idx) => (
              <div key={step.label} className="flex items-center gap-2">
                <div className="flex flex-col items-center gap-2 px-5 py-4 rounded-2xl border-2 min-w-[130px] text-center hover:shadow-md transition-shadow"
                  style={{ borderColor: step.color + "30", background: step.bg }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: step.color + "20" }}>
                    <step.icon size={20} style={{ color: step.color }} />
                  </div>
                  <span className="text-sm font-bold text-slate-800" style={{ fontFamily: "Cairo, sans-serif" }}>{step.label}</span>
                </div>
                {idx < 4 && <div className="hidden lg:flex items-center text-slate-300"><ArrowLeft size={20} /></div>}
              </div>
            ))}
          </div>
          <div id="calc" className="mt-20">
            <SectionTitle badge="آلية الحساب" title="كيف يتم حساب مؤشر النبض؟"
              subtitle="يعتمد المؤشر على خمسة عوامل رئيسية تُحلَّل يوميًا بواسطة الذكاء الاصطناعي." />
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { icon: Wallet, label: "الإنفاق مقارنة بالدخل", pct: "30%", color: "#1D4ED8" },
                { icon: Target, label: "الالتزام بالميزانية", pct: "20%", color: "#7C3AED" },
                { icon: PiggyBank, label: "نمو المدخرات", pct: "25%", color: "#16A34A" },
                { icon: ShoppingCart, label: "السلوك الشرائي والقرارات اللحظية", pct: "15%", color: "#F59E0B" },
                { icon: CreditCard, label: "انتظام سداد الالتزامات المالية", pct: "10%", color: "#0EA5E9" },
              ].map(item => (
                <div key={item.label} className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm hover:shadow-md transition-shadow text-center">
                  <div className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-3" style={{ background: item.color + "15" }}>
                    <item.icon size={22} style={{ color: item.color }} />
                  </div>
                  <div className="text-2xl font-black mb-1" style={{ color: item.color, fontFamily: "Cairo, sans-serif" }}>{item.pct}</div>
                  <p className="text-sm text-slate-600 font-semibold leading-tight" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────── FEATURES ─────────────── */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="المميزات" title="مميزات نبض"
            subtitle="سبع ميزات متكاملة تجعل نبض الرفيق المالي الذكي الذي تحتاجه كل يوم." />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Activity, title: "مؤشر النبض المالي", desc: "درجة مالية يومية من 0 إلى 100 توضح حالتك المالية بشكل فوري وسهل الفهم.", gradient: "linear-gradient(135deg,#1D4ED8,#2563EB)" },
              { icon: TrendingUp, title: "التنبؤ المالي الاستباقي", desc: "يتوقع تأثير سلوكك المالي الحالي على وضعك المستقبلي قبل وقوع المشكلة.", gradient: "linear-gradient(135deg,#16A34A,#15803D)" },
              { icon: Bell, title: "التنبيهات الذكية", desc: "تنبيهات مخصصة تعتمد على سلوكك الفعلي: اشتراكات منسية، إنفاق مرتفع، وأكثر.", gradient: "linear-gradient(135deg,#F59E0B,#D97706)" },
              { icon: Bot, title: "المساعد المالي الذكي", desc: "مساعد ذكاء اصطناعي يجيب عن أسئلتك المالية ويقدم توصيات بناءً على بياناتك.", gradient: "linear-gradient(135deg,#7C3AED,#6D28D9)" },
              { icon: Calculator, title: "الحاسبة المالية الذكية", desc: "تحسب تلقائيًا المبلغ الآمن للإنفاق اليومي بعد احتساب الراتب والالتزامات.", gradient: "linear-gradient(135deg,#0EA5E9,#0284C7)" },
              { icon: FlaskConical, title: "محاكاة القرارات المالية", desc: "اعرف أثر أي عملية شراء على مؤشرك المالي قبل تنفيذها وتجنب الندم.", gradient: "linear-gradient(135deg,#EC4899,#DB2777)" },
              { icon: Users, title: "مجتمع نبض", desc: "قارن أداءك المالي مع أشخاص مشابهين لك في العمر والدخل والمدينة بشكل مجهول وآمن.", gradient: "linear-gradient(135deg,#1D4ED8,#16A34A)" },
            ].map(f => <FeatureCard key={f.title} {...f} />)}
          </div>
        </div>
      </section>

      {/* ─────────────── SIMULATION ─────────────── */}
      <section className="py-24" style={{ background: "linear-gradient(160deg,#EFF6FF 0%,#F0FDF4 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="محاكاة القرارات" title="قبل أن تشتري، اسأل نبض"
            subtitle="اعرف أثر أي قرار شرائي على مؤشرك المالي في الوقت الفعلي قبل أن تضغط على تأكيد الشراء." />
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-slate-100">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center"><FlaskConical size={20} className="text-blue-600" /></div>
                <div>
                  <div className="font-bold text-slate-900" style={{ fontFamily: "Cairo, sans-serif" }}>محاكاة الشراء</div>
                  <div className="text-xs text-slate-400">حرك المنزلق لمعرفة التأثير</div>
                </div>
              </div>
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-semibold text-slate-700">قيمة الشراء</label>
                  <span className="text-2xl font-black text-blue-700" style={{ fontFamily: "Cairo, sans-serif" }}>{simulationValue} ر.س</span>
                </div>
                <input type="range" min={50} max={2000} step={50} value={simulationValue}
                  onChange={e => setSimulationValue(Number(e.target.value))}
                  className="w-full h-2 rounded-full appearance-none cursor-pointer"
                  style={{ background: `linear-gradient(to left, #1D4ED8 ${(simulationValue / 2000) * 100}%, #E2E8F0 ${(simulationValue / 2000) * 100}%)` }} />
                <div className="flex justify-between text-xs text-slate-400 mt-1"><span>50 ر.س</span><span>2000 ر.س</span></div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-green-50 rounded-2xl p-4 text-center border border-green-100">
                  <div className="text-xs text-slate-500 mb-2">المؤشر الحالي</div>
                  <div className="text-4xl font-black text-green-600" style={{ fontFamily: "Cairo, sans-serif" }}>78</div>
                </div>
                <div className="bg-amber-50 rounded-2xl p-4 text-center border border-amber-100">
                  <div className="text-xs text-slate-500 mb-2">بعد الشراء</div>
                  <div className="text-4xl font-black" style={{ fontFamily: "Cairo, sans-serif", color: afterPurchaseScore >= 70 ? "#16A34A" : afterPurchaseScore >= 50 ? "#F59E0B" : "#DC2626" }}>{afterPurchaseScore}</div>
                </div>
              </div>
              <div className="rounded-2xl p-4 text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
                <div className="flex items-center gap-2 mb-2"><Sparkles size={16} /><span className="font-bold text-sm">توصية نبض</span></div>
                <p className="text-sm opacity-90 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
                  {afterPurchaseScore >= 72 ? "الشراء آمن ولن يؤثر على أهدافك الادخارية. تفضل!"
                    : afterPurchaseScore >= 60 ? "يُفضّل تأجيل الشراء 5 أيام للحفاظ على هدفك الادخاري."
                    : "هذا الشراء سيؤثر بشكل ملحوظ على صحتك المالية. ننصح بالتأجيل."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────── ALERTS ─────────────── */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="التنبيهات الذكية" title="تنبيهات تفهمك قبل أن تتعثر"
            subtitle="تنبيهات مخصصة تعتمد على سلوكك المالي الفعلي لتحذيرك قبل وقوع المشكلة." />
          <div className="max-w-xl mx-auto flex flex-col gap-4">
            <AlertCard icon={Bell} color="#7C3AED" text="لديك اشتراك غير مستخدم منذ 3 أشهر — وفّر 49 ر.س شهريًا بإلغائه" time="قبل لحظات" />
            <AlertCard icon={TrendingUp} color="#DC2626" text="أنفقت هذا الأسبوع أكثر من المعتاد بنسبة 18% — راجع إنفاق المطاعم" time="منذ ساعتين" />
            <AlertCard icon={ShoppingCart} color="#F59E0B" text="اقتربت من تجاوز ميزانية التسوق المحددة، تبقى 120 ر.س" time="اليوم 10:30 ص" />
            <AlertCard icon={PiggyBank} color="#16A34A" text="يمكنك توفير 240 ر.س هذا الشهر إذا خففت الإنفاق على الطلبات" time="اليوم 08:00 ص" />
          </div>
        </div>
      </section>

      {/* ─────────────── AI ASSISTANT ─────────────── */}
      <section className="py-24" style={{ background: "linear-gradient(160deg,#EFF6FF 0%,#F0FDF4 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="المساعد الذكي" title="مساعدك المالي الذكي"
            subtitle="اسأله أي سؤال مالي شخصي وسيجيبك بناءً على بياناتك الفعلية." />
          <div className="max-w-lg mx-auto">
            <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
              <div className="px-5 py-4 flex items-center gap-3 text-white" style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center"><Bot size={18} className="text-white" /></div>
                <div>
                  <div className="font-bold text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>مساعد نبض</div>
                  <div className="text-xs opacity-80">متصل الآن</div>
                </div>
                <div className="mr-auto"><div className="w-2 h-2 bg-green-300 rounded-full animate-pulse" /></div>
              </div>
              <div className="h-64 overflow-y-auto px-4 py-4 flex flex-col gap-3">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.from === "user" ? "justify-start" : "justify-end"}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${msg.from === "user" ? "bg-slate-100 text-slate-800 rounded-tr-sm" : "text-white rounded-tl-sm"}`}
                      style={{ background: msg.from === "bot" ? "linear-gradient(135deg,#1D4ED8,#16A34A)" : undefined, fontFamily: "Tajawal, sans-serif" }}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>
              <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-2">
                <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && sendChat()}
                  placeholder="اسأل عن وضعك المالي..."
                  className="flex-1 bg-slate-50 rounded-xl px-4 py-2.5 text-sm outline-none border border-slate-200 focus:border-blue-300 transition-colors"
                  style={{ fontFamily: "Tajawal, sans-serif" }} />
                <button onClick={sendChat} className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-90"
                  style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)" }}>
                  <Send size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────── COMMUNITY ─────────────── */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="مجتمع نبض" title="قارن أداءك بشكل آمن ومجهول"
            subtitle="ميزة اختيارية تتيح لك مقارنة أدائك المالي مع أشخاص مشابهين لك دون كشف أي بيانات شخصية." />
          <div className="max-w-3xl mx-auto grid sm:grid-cols-3 gap-6">
            {[
              { icon: Shield, color: "#1D4ED8", bg: "#EFF6FF", title: "مقارنة مجهولة وآمنة", desc: "بياناتك الشخصية مشفرة بالكامل ولا تُشارك مطلقًا." },
              { icon: Users, color: "#16A34A", bg: "#F0FDF4", title: "مشابهون لك", desc: "أشخاص في نفس الفئة العمرية والدخلية والمدينة." },
              { icon: Star, color: "#F59E0B", bg: "#FFFBEB", title: "تحفيز للتحسن", desc: "اعرف أين أنت وما الذي يفعله الآخرون للتحسن." },
            ].map(item => (
              <div key={item.title} className="rounded-3xl p-6 border border-slate-100 text-center hover:shadow-md transition-shadow" style={{ background: item.bg }}>
                <div className="w-14 h-14 rounded-2xl mx-auto flex items-center justify-center mb-4" style={{ background: item.color + "20" }}>
                  <item.icon size={26} style={{ color: item.color }} />
                </div>
                <h3 className="font-bold text-slate-900 mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 max-w-xl mx-auto bg-white rounded-3xl p-6 shadow-md border border-slate-100">
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm font-bold text-slate-700" style={{ fontFamily: "Cairo, sans-serif" }}>مقارنة مع المجموعة المشابهة لك</span>
              <span className="text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-semibold">الرياض · 25-35 سنة</span>
            </div>
            {[
              { label: "متوسط مؤشر المجموعة", value: 71, yours: 78, color: "#1D4ED8" },
              { label: "متوسط الادخار الشهري", value: 62, yours: 75, color: "#16A34A" },
              { label: "الالتزام بالميزانية", value: 55, yours: 80, color: "#7C3AED" },
            ].map(item => (
              <div key={item.label} className="mb-4 last:mb-0">
                <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                  <span>{item.label}</span>
                  <span className="font-semibold" style={{ color: item.color }}>أنت: {item.yours} | المجموعة: {item.value}</span>
                </div>
                <div className="relative h-2 bg-slate-100 rounded-full">
                  <div className="h-full rounded-full opacity-40" style={{ width: `${item.value}%`, background: item.color }} />
                  <div className="absolute top-0 h-full rounded-full" style={{ width: `${item.yours}%`, background: item.color }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─────────────── INNOVATION ─────────────── */}
      <section id="innovation" className="py-24" style={{ background: "linear-gradient(160deg,#0F1923 0%,#1E3A5F 50%,#14532D 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <div className="flex justify-center mb-4">
              <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-semibold bg-white/10 text-white border border-white/20">
                <Sparkles size={14} />الابتكار
              </span>
            </div>
            <h2 className="text-4xl font-black text-white mb-4" style={{ fontFamily: "Cairo, sans-serif" }}>ما الذي يجعل نبض مختلفًا؟</h2>
            <p className="text-lg text-white/60 max-w-2xl mx-auto" style={{ fontFamily: "Tajawal, sans-serif" }}>
              نبض لا يعرض البيانات فقط — بل يحوّلها إلى مؤشر صحي مالي مفهوم ويتنبأ بالمشكلات قبل وقوعها.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Activity, title: "مؤشر صحي لا مجرد بيانات", desc: "يحوّل الأرقام المعقدة إلى رقم واحد سهل المتابعة كمؤشر النبض الطبي." },
              { icon: Zap, title: "استباقي لا رجعي", desc: "يتنبأ بالمشكلات المالية قبل وقوعها ولا ينتظر انتهاء الشهر لإعلامك." },
              { icon: Target, title: "توجيه في لحظة القرار", desc: "يرشدك قبل الشراء لا بعده، مما يمنعك من القرارات غير المحسوبة." },
              { icon: Star, title: "مصمم للسوق السعودي", desc: "يفهم الأنماط المالية المحلية ويراعي رمضان والأعياد والالتزامات الاجتماعية." },
              { icon: BrainCircuit, title: "ذكاء اصطناعي حقيقي", desc: "يتعلم من سلوكك الفعلي ويُحسّن توصياته بمرور الوقت ليلائمك تمامًا." },
              { icon: Shield, title: "خصوصية بلا تنازلات", desc: "بياناتك مشفرة ولا تُشارك مع أحد. أمانك المالي أولويتنا الأولى." },
            ].map(item => (
              <div key={item.title} className="rounded-3xl p-6 border border-white/10 hover:bg-white/10 transition-colors" style={{ background: "rgba(255,255,255,0.05)" }}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 bg-white/10"><item.icon size={22} className="text-white" /></div>
                <h3 className="text-lg font-bold text-white mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>{item.title}</h3>
                <p className="text-sm text-white/60 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─────────────── BANK VALUE ─────────────── */}
      <section id="bank-value" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle badge="القيمة للبنك" title="القيمة المضافة لبنك الإنماء"
            subtitle="نبض ليس فقط أداة للعميل — بل شريك استراتيجي للبنك في رحلة التحول الرقمي." />
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="flex flex-col gap-4">
              {[
                { icon: TrendingUp, color: "#1D4ED8", title: "تعزيز الثقافة المالية", desc: "يرفع وعي العملاء بصحتهم المالية ويبني علاقة ثقة طويلة الأمد مع البنك." },
                { icon: Star, color: "#16A34A", title: "زيادة رضا العملاء وولائهم", desc: "عملاء يشعرون أن البنك يهتم بمستقبلهم المالي هم عملاء يبقون." },
                { icon: Shield, color: "#7C3AED", title: "تقليل احتمالية التعثر المالي", desc: "الإنذار المبكر يُقلل معدلات التخلف عن السداد ويحمي محفظة البنك." },
                { icon: Target, color: "#F59E0B", title: "خدمات أكثر دقة وملاءمة", desc: "فهم سلوك العملاء يُمكّن البنك من تقديم منتجات مالية مناسبة تمامًا." },
                { icon: BrainCircuit, color: "#0EA5E9", title: "دعم التحول الرقمي والشمول المالي", desc: "يُسرّع مسيرة رقمنة الخدمات ويدعم مستهدفات رؤية 2030." },
              ].map(item => (
                <div key={item.title} className="flex items-start gap-4 bg-slate-50 rounded-2xl p-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: item.color + "15" }}>
                    <item.icon size={20} style={{ color: item.color }} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-0.5" style={{ fontFamily: "Cairo, sans-serif" }}>{item.title}</h4>
                    <p className="text-sm text-slate-500 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex flex-col items-center gap-4">
              <div className="w-full rounded-3xl p-8 text-white text-center" style={{ background: "linear-gradient(135deg,#1D4ED8 0%,#16A34A 100%)" }}>
                <div className="text-5xl mb-4">🏦</div>
                <div className="text-2xl font-black mb-2" style={{ fontFamily: "Cairo, sans-serif" }}>بنك الإنماء</div>
                <div className="text-white/70 text-sm">شريك استراتيجي في الابتكار المالي</div>
              </div>
              <div className="flex items-center gap-4 w-full">
                <div className="flex-1 bg-blue-50 rounded-2xl p-5 text-center border border-blue-100">
                  <div className="text-3xl mb-2">💓</div>
                  <div className="font-bold text-blue-700 text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>منصة نبض</div>
                  <div className="text-xs text-slate-400 mt-1">الذكاء الاصطناعي</div>
                </div>
                <div className="text-3xl text-slate-300">+</div>
                <div className="flex-1 bg-green-50 rounded-2xl p-5 text-center border border-green-100">
                  <div className="text-3xl mb-2">👤</div>
                  <div className="font-bold text-green-700 text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>العميل</div>
                  <div className="text-xs text-slate-400 mt-1">قرارات مالية أفضل</div>
                </div>
              </div>
              <div className="w-full bg-gradient-to-l from-blue-600/10 to-green-600/10 rounded-2xl p-4 border border-blue-100 text-center">
                <CheckCircle size={20} className="text-green-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700" style={{ fontFamily: "Tajawal, sans-serif" }}>نتيجة: عملاء أكثر وعيًا، ولاء أعمق، وعوائد أفضل</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────── VISION ─────────────── */}
      <section id="vision" className="py-32 text-center relative overflow-hidden" style={{ background: "linear-gradient(160deg,#EFF6FF 0%,#F0FDF4 100%)" }}>
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full opacity-10"
            style={{ background: "radial-gradient(circle,#1D4ED8,transparent)" }} />
        </div>
        <div className="max-w-3xl mx-auto px-4 relative">
          <div className="flex justify-center mb-6"><GradientBadge><Star size={14} />رؤيتنا</GradientBadge></div>
          <h2 className="text-5xl font-black text-slate-900 mb-6 leading-tight" style={{ fontFamily: "Cairo, sans-serif" }}>
            المؤشر المالي اليومي<br />
            <span style={{ background: "linear-gradient(135deg,#1D4ED8,#16A34A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>الأول في المملكة</span>
          </h2>
          <p className="text-xl text-slate-500 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
            أن يصبح <strong className="text-blue-700">نبض</strong> المؤشر المالي اليومي الأول في المملكة، بحيث يتمكن كل عميل من متابعة صحته المالية بسهولة واتخاذ قرارات مالية أكثر وعيًا.
          </p>
          <div className="mt-12 grid grid-cols-3 gap-6 max-w-lg mx-auto">
            {[{ number: "٠-١٠٠", label: "مؤشر يومي" }, { number: "+١م", label: "مستخدم مستهدف" }, { number: "٢٤/٧", label: "متابعة مستمرة" }].map(stat => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-black mb-1" style={{ fontFamily: "Cairo, sans-serif", background: "linear-gradient(135deg,#1D4ED8,#16A34A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  {stat.number}
                </div>
                <div className="text-sm text-slate-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─────────────── CTA ─────────────── */}
      <section id="cta" className="py-24 relative overflow-hidden" style={{ background: "linear-gradient(135deg,#1D4ED8 0%,#16A34A 100%)" }}>
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-white/5" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-white/5" />
        </div>
        <div className="max-w-3xl mx-auto px-4 text-center relative">
          <div className="flex justify-center mb-6">
            <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-semibold bg-white/20 text-white border border-white/30">
              <Activity size={14} />ابدأ رحلتك المالية
            </span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black text-white mb-4 leading-tight" style={{ fontFamily: "Cairo, sans-serif" }}>
            ابدأ رحلتك نحو<br />صحة مالية أفضل
          </h2>
          <p className="text-lg text-white/80 mb-10 leading-relaxed" style={{ fontFamily: "Tajawal, sans-serif" }}>
            تابع نبضك المالي يوميًا، وافهم قراراتك قبل أن تؤثر على مستقبلك.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button onClick={() => navigate("auth")}
              className="px-8 py-4 bg-white text-blue-700 rounded-2xl font-black text-base hover:shadow-2xl hover:scale-105 transition-all"
              style={{ fontFamily: "Cairo, sans-serif" }}>
              ابدأ الآن
            </button>
            <button onClick={() => navigate("auth")}
              className="px-8 py-4 bg-white/10 border border-white/30 text-white rounded-2xl font-bold text-base hover:bg-white/20 transition-all"
              style={{ fontFamily: "Cairo, sans-serif" }}>
              احجز عرضًا توضيحيًا
            </button>
          </div>
        </div>
      </section>

      {/* ─────────────── FOOTER ─────────────── */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">💓</span>
                <span className="text-xl font-black" style={{ fontFamily: "Cairo, sans-serif", background: "linear-gradient(135deg,#60A5FA,#4ADE80)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>نبض | Pulse</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed max-w-xs" style={{ fontFamily: "Tajawal, sans-serif" }}>
                صحتك المالية تبدأ من نبضة. منصة ذكية تحوّل بياناتك المالية إلى مؤشر واضح يساعدك على اتخاذ قرارات أفضل كل يوم.
              </p>
            </div>
            <div>
              <div className="font-bold text-sm mb-4 text-slate-300" style={{ fontFamily: "Cairo, sans-serif" }}>روابط سريعة</div>
              <div className="flex flex-col gap-2">
                {["الرئيسية", "المشكلة", "الحل", "المميزات", "الابتكار", "الرؤية"].map(link => (
                  <a key={link} href="#" className="text-sm text-slate-400 hover:text-white transition-colors" style={{ fontFamily: "Tajawal, sans-serif" }}>{link}</a>
                ))}
              </div>
            </div>
            <div>
              <div className="font-bold text-sm mb-4 text-slate-300" style={{ fontFamily: "Cairo, sans-serif" }}>تواصل معنا</div>
              <div className="flex flex-col gap-2 text-sm text-slate-400" style={{ fontFamily: "Tajawal, sans-serif" }}>
                <span>الرياض، المملكة العربية السعودية</span>
                <span>hello@pulse-sa.com</span>
                <div className="flex gap-3 mt-2">
                  {["𝕏", "in", "📧"].map(icon => (
                    <button key={icon} className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 flex items-center justify-center text-sm transition-colors">{icon}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-slate-500" style={{ fontFamily: "Tajawal, sans-serif" }}>© 2025 نبض | Pulse. جميع الحقوق محفوظة.</p>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">مبني بـ</span>
              <span className="text-red-400">💓</span>
              <span className="text-xs text-slate-500">في المملكة العربية السعودية</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Main App Router
// ─────────────────────────────────────────────────────────────────
export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("landing");

  const navigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (currentPage === "landing") return <LandingPage navigate={navigate} />;
  if (currentPage === "auth") return <AuthPage navigate={navigate} />;
  if (currentPage === "login") return <LoginPage navigate={navigate} />;
  if (currentPage === "signup") return <SignupPage navigate={navigate} />;
  if (currentPage === "setup-intro") return <SetupIntroPage navigate={navigate} />;
  if (currentPage === "setup-basic") return <SetupBasicPage navigate={navigate} />;
  if (currentPage === "setup-income") return <SetupIncomePage navigate={navigate} />;
  if (currentPage === "setup-commitments") return <SetupCommitmentsPage navigate={navigate} />;
  if (currentPage === "setup-budget") return <SetupBudgetPage navigate={navigate} />;
  if (currentPage === "setup-goals") return <SetupGoalsPage navigate={navigate} />;
  if (currentPage === "setup-bank") return <SetupBankPage navigate={navigate} />;
  if (currentPage === "analyzing") return <AnalyzingPage navigate={navigate} />;
  if (currentPage === "first-result") return <FirstResultPage navigate={navigate} />;
  if (currentPage === "dashboard") return <DashboardPage navigate={navigate} />;

  return <LandingPage navigate={navigate} />;
}
