
  # تصميم موقع نبض المالي

  This is a code bundle for تصميم موقع نبض المالي. The original project is available at https://www.figma.com/design/v1xJ8hbEL6yjNhbQo93Rdq/%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D9%85%D9%88%D9%82%D8%B9-%D9%86%D8%A8%D8%B6-%D8%A7%D9%84%D9%85%D8%A7%D9%84%D9%8A.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  